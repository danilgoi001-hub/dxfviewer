# DxfViewer (Android 11+)
Build a **debug APK** without keys. Either:
- Locally in Android Studio (Build > Build APKs), or
- Push this repo to GitHub and use the included **Actions** workflow — it will build and attach `app-debug.apk` as an artifact.
